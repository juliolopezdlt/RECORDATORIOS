<script setup>
import { ref, onMounted } from "vue";
import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";
import { useRouter } from "vue-router";

const router = useRouter();
const logueado = ref(false);
const auth = getAuth();

onMounted(() => {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      logueado.value = user;
      console.log("usuario logueado");

      //creamos la variable para que el main la vea
      localStorage.setItem("idUsuario", user.uid);
    } else {
      //eliminamos la variable si cierra sesion
      localStorage.removeItem("idUsuario");
      logueado.value = null;
      console.log("no hay usuario");
    }
  });
});
</script>
<template>
  <header>
    <h1>Mis Recordatorios</h1>
    <nav>
      <RouterLink to="/">Inicio</RouterLink>

      <RouterLink v-if="!logueado" to="/login">Login</RouterLink>

      <RouterLink v-if="logueado" to="/privado">Mi Panel</RouterLink>
    </nav>
  </header>

  <main>
    <RouterView />
  </main>
</template>

<style></style>
