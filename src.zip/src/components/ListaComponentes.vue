<script setup>
import { ref, computed } from "vue";
import { collection, query, where } from "firebase/firestore";
import { updateDoc } from "firebase/firestore";
import { useCollection } from "vuefire";
import { db } from "../main.js";
import { doc, deleteDoc } from "firebase/firestore";

//id de usuario para diferenciar las listas de tareas
const props = defineProps({
  idUsuario: String,
  nombreUsuario: String,
});

//VARIABLE PARA EL ADMIN
const esAdmin = computed(() => {
  const idAdmin = "W23W5SSFqAXsMN7aV9dMU8WssQ22";
  return props.idUsuario === idAdmin;
});

const consulta = computed(() => {
  if (!props.idUsuario) return null;

  const idAdmin = "W23W5SSFqAXsMN7aV9dMU8WssQ22";

  if (props.idUsuario == idAdmin) {
    return collection(db, "tareas");
  } else {
    return query(
      collection(db, "tareas"),
      where("usuario", "==", props.idUsuario),
    );
  }
});

const tareas = useCollection(consulta);

async function borrarListaTareas() {
  //recorremos la lista tareas
  // 't' es cada tarea individual de tu array
  tareas.value.forEach(async (tarea) => {
    await deleteDoc(doc(db, "tareas", tarea.id));
  });

  console.log("Cementerio vaciado...");
}

var indiceModal = ref("");
var mostrarModal = ref(false);

function borrarElemento(id) {
  // Guardamos el índice del elemento que el usuario quiere borrar
  indiceModal.value = id;
  // Abrimos el modal
  mostrarModal.value = true;
}

//FUNCION BORRADO
async function borrado() {
  if (indiceModal.value !== null) {
    await deleteDoc(doc(db, "tareas", indiceModal.value));

    cerrarModal();
  }
}

//FUNCION PARA CERRAR MODAL
function cerrarModal() {
  mostrarModal.value = false;
  indiceModal.value = null;
}

var editarElemento = ref(null);
//ACTUALIZAR PRODUCTO
async function actualizarProducto(id, nuevoNombre) {
  const nuevaTarea = doc(db, "tareas", id);
  await updateDoc(nuevaTarea, { nombre: nuevoNombre });
  editarElemento.value = null;
}
</script>
<template>
  <div>
    <button @click="borrarListaTareas">Borrar lista</button>
    <div v-if="tareas.length == 0">No hay recordatorios...</div>
    <div v-else>
      <ul>
        <li v-for="tarea in tareas" :key="tarea.id">
          <div v-if="esAdmin">
            <p>Usuario: {{ tarea.nombreUsuario }}</p>
          </div>
          <span>{{ tarea.nombre }} </span>
          <button @click="borrarElemento(tarea.id)">🗑️</button>
          <button @click="editarElemento = tarea.id">✏️</button>

          <div v-if="editarElemento == tarea.id">
            <input
              v-model="tarea.nombre"
              @keyup.enter="actualizarProducto(tarea.id, tarea.nombre)"
            />
            <button @click="actualizarProducto(tarea.id, tarea.nombre)">
              Cambiar
            </button>
            <button @click="editarElemento = null">Cancelar</button>
          </div>
        </li>
      </ul>

      <div v-if="mostrarModal">
        <p>Estas seguro de que quieres borrar el elemento</p>
        <button @click="borrado">Si</button>
        <button @click="cerrarModal">No</button>
      </div>
    </div>
  </div>
</template>
<style scoped>
/* Contenedor Principal */
/* Contenedor principal y estados vacíos */
.lista-container {
  max-width: 600px;
  margin: 2rem auto;
  font-family: "Segoe UI", Roboto, sans-serif;
}

.empty-state {
  text-align: center;
  color: #b2bec3;
  font-style: italic;
  padding: 2rem;
}

/* Botón general para vaciar lista */
.btn-borrar-todo {
  display: block;
  margin-bottom: 1.5rem;
  background: none;
  border: 1px solid #ff7675;
  color: #ff7675;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.8rem;
  text-transform: uppercase;
  transition: all 0.3s ease;
}

.btn-borrar-todo:hover {
  background: #ff7675;
  color: white;
}

/* Estilo de la lista */
ul {
  list-style: none;
  padding: 0;
}

li {
  background: #ffffff;
  border: 1px solid #f0f0f0;
  border-radius: 8px;
  padding: 1rem 1.5rem;
  margin-bottom: 0.8rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  transition: box-shadow 0.3s ease;
}

li:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

/* Texto de la tarea y admin */
li span {
  flex: 1;
  color: #2d3436;
  font-size: 1rem;
}

.admin-tag {
  font-size: 0.7rem;
  color: #636e72;
  font-weight: bold;
  text-transform: uppercase;
  margin-bottom: 0.2rem;
  display: block;
}

/* Botones de acción (iconos) */
.btn-icon {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1.1rem;
  padding: 5px;
  border-radius: 4px;
  transition: background 0.2s;
}

.btn-icon:hover {
  background: #f5f6fa;
}

/* Formulario de edición dentro del item */
.edit-box {
  display: flex;
  gap: 0.5rem;
  margin-top: 0.8rem;
  width: 100%;
}

.edit-box input {
  padding: 0.4rem;
  border: 1px solid #dfe6e9;
  border-radius: 4px;
  flex: 1;
}

/* Modal de confirmación */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(44, 62, 80, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}

.modal-content p {
  margin-bottom: 1.5rem;
  color: #2d3436;
  font-weight: 500;
}

.btn-confirm {
  background: #2d3436;
  color: white;
  border: none;
  padding: 0.6rem 1.5rem;
  margin: 0 0.5rem;
  border-radius: 4px;
  cursor: pointer;
}

.btn-cancel {
  background: #dfe6e9;
  color: #2d3436;
  border: none;
  padding: 0.6rem 1.5rem;
  margin: 0 0.5rem;
  border-radius: 4px;
  cursor: pointer;
}
</style>
