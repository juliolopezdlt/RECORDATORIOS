<script setup>
import { ref } from "vue";
import { db } from "../main.js"; // Importamos la db que configuraste en main.js
import { collection, addDoc } from "firebase/firestore";

const props = defineProps({
  idUsuario: String,
  nombreUsuario: String,
});

var valueInput = ref("");

async function anadirElemento() {
  if (valueInput.value.trim() === "") return;

  await addDoc(collection(db, "tareas"), {
    nombre: valueInput.value,
    tachar: false,
    usuario: props.idUsuario,
    fecha: new Date(),
    nombreUsuario: props.nombreUsuario,
  });

  /*listaCompra.value.push({
    nombre: valueInput.value,
    tachar: false,
    cantidad: 1,
  });*/

  console.log("tarea añadida");
  valueInput.value = "";
}
</script>
<template>
  <div>
    <input
      @keyup.enter="anadirElemento"
      v-model="valueInput"
      placeholder="Qué quieres recordar?"
    />
    <button @click="anadirElemento">Añadir</button>
  </div>
</template>
<style scoped>
/* Contenedor de la barra de entrada */
.input-container {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  padding: 2.5rem 0;
  max-width: 600px;
  margin: 0 auto;
}

input {
  flex: 1;
  padding: 0.8rem 1.2rem;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 1rem;
  font-family: "Segoe UI", sans-serif;
  color: #2d3436;
  background-color: #fcfcfc;
  transition: all 0.3s ease;
  outline: none;
}

input::placeholder {
  color: #b2bec3;
  font-style: italic;
  font-weight: 300;
}

input:focus {
  border-color: #2c3e50;
  background-color: #ffffff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.03);
}

button {
  padding: 0.8rem 1.8rem;
  background-color: #2c3e50;
  color: #ffffff;
  border: none;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

button:hover {
  background-color: #34495e;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(44, 62, 80, 0.2);
}

button:active {
  transform: translateY(0);
}
</style>
