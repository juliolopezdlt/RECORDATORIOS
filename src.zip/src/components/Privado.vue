<script setup>
import { ref, onMounted } from "vue";
import { getAuth, onAuthStateChanged } from "firebase/auth";

import PerfilUsuario from "./PerfilUsuario.vue";
import NuevoRecordatorio from "./NuevoRecordatorio.vue";
import ListaComponentes from "./ListaComponentes.vue";

const usuario = ref(null);

const auth = getAuth();

onMounted(() => {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      usuario.value = user;
    }
  });
});
</script>

<template>
  <div v-if="usuario">
    <h2>Mi Panel Privado</h2>

    <PerfilUsuario :usuario="usuario" />
    <hr />

    <NuevoRecordatorio
      :idUsuario="usuario.uid"
      :nombreUsuario="usuario.email"
    />
    <ListaComponentes :idUsuario="usuario.uid" />
  </div>
</template>
<style scole>
/* Contenedor principal del Dashboard */
.panel-privado {
  max-width: 900px;
  margin: 2rem auto;
  padding: 2rem;
  background-color: #ffffff;
  border-radius: 16px;
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
  font-family: "Segoe UI", Roboto, sans-serif;
}

/* Título de la sección */
h2 {
  color: #2c3e50;
  font-size: 1.8rem;
  font-weight: 700;
  margin-bottom: 2rem;
  text-align: left;
  letter-spacing: -0.5px;
  border-left: 4px solid #2c3e50;
  padding-left: 1rem;
}

/* Separador elegante */
hr {
  border: 0;
  height: 1px;
  background-image: linear-gradient(
    to right,
    rgba(0, 0, 0, 0),
    rgba(0, 0, 0, 0.1),
    rgba(0, 0, 0, 0)
  );
  margin: 2.5rem 0;
}

/* Ajustes de espaciado entre sub-componentes */
.panel-privado > div {
  margin-bottom: 1.5rem;
}

/* Contenedor de la lista de recordatorios (opcional para dar aire) */
.lista-section {
  background-color: #fcfcfc;
  border-radius: 12px;
  padding: 1.5rem;
  margin-top: 2rem;
}

/* Animación de entrada suave para el panel */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.panel-privado {
  animation: fadeIn 0.5s ease-out;
}
</style>
