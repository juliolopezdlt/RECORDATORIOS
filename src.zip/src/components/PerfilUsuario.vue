<script setup>
import { getAuth, signOut } from "firebase/auth";

import { useRouter } from "vue-router";

const router = useRouter();

const props = defineProps({
  usuario: Object,
  nombreUsuario: String,
});

function cerrarSesion() {
  const auth = getAuth();
  signOut(auth)
    .then(() => {
      console.log("Ha cerrado la sesion");
      localStorage.removeItem("idUsuario");
      router.push("/");
    })
    .catch((error) => {
      console.log("Error al salir");
    });
}
</script>
<template>
  <div class="bienvenido">
    Bienvenido, {{ usuario.displayName }} >
    <img :src="usuario.photoURL" />
    <button @click="cerrarSesion">Cerrar sesión</button>
  </div>
</template>

<style scoped>
.bienvenido {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 1.5rem;
  padding: 1rem 2rem;
  background-color: #ffffff;
  color: #2c3e50;
  font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-weight: 300;
  letter-spacing: 0.5px;
  border-bottom: 1px solid #ececec;
  transition: all 0.3s ease;
}

.bienvenido img {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #f0f0f0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.bienvenido button {
  background-color: transparent;
  color: #636e72;
  border: 1px solid #dfe6e9;
  padding: 0.5rem 1.2rem;
  border-radius: 4px;
  font-size: 0.85rem;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
}

.bienvenido button:hover {
  background-color: #2c3e50;
  color: #ffffff;
  border-color: #2c3e50;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.bienvenido button:active {
  transform: translateY(1px);
}
</style>
