<script setup></script>
<template>
  <div class="hero-container">
    <h2>Bienvenido a la App de Recordatorios</h2>
    <p>
      Organiza tu día de forma sencilla. Inicia sesión para empezar a crear tus
      recordatorios.
    </p>
    <img src="/recordar.png" class="hero-image" alt="Recordatorios" />
  </div>
</template>
<style scole>
.hero-container {
  max-width: 800px;
  margin: 4rem auto;
  text-align: center;
  padding: 3rem 2rem;
  background: linear-gradient(145deg, #ffffff, #f9f9f9);
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.02);
  font-family: "Segoe UI", Roboto, Helvetica, sans-serif;
}

h2 {
  color: #2c3e50;
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  letter-spacing: -0.5px;
  position: relative;
}

h2::after {
  content: "";
  display: block;
  width: 50px;
  height: 3px;
  background-color: #2c3e50;
  margin: 1rem auto;
  border-radius: 2px;
}

p {
  color: #636e72;
  font-size: 1.1rem;
  line-height: 1.8;
  max-width: 500px;
  margin: 0 auto;
  font-weight: 300;
}

/* Decoración sutil */
.hero-container::before {
  content: "✦";
  font-size: 1.5rem;
  color: #dfe6e9;
  display: block;
  margin-bottom: 1rem;
}
</style>
