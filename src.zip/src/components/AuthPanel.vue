<script setup>
import { ref } from "vue";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  OAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  setPersistence,
  browserSessionPersistence,
} from "firebase/auth";
import { useRouter } from "vue-router";

const router = useRouter();

//variables para los inicios
const auth = getAuth();
const provider = new GoogleAuthProvider();
const msProvider = new OAuthProvider("microsoft.com");

var registrado = ref(false);
var iniciado = ref(false);
var olvidadoContraseña = ref(false);
var correoOlvidado = ref("");
const email = ref("");
const contra = ref("");

const iniciarSesionEmail = () => {
  setPersistence(auth, browserSessionPersistence)
    .then(() => {
      return signInWithEmailAndPassword(auth, email.value, contra.value);
    })
    .then((userCredential) => {
      localStorage.setItem("idUsuario", userCredential.user.uid);

      router.push("/privado");
      console.log("Logueado con Email");
    })
    .catch((error) => {
      console.error("Error Email:", error.message);
      alert("Email o contraseña incorrectos");
    });
};

const iniciaSesionMicrosoft = () => {
  setPersistence(auth, browserSessionPersistence)
    .then(() => {
      return signInWithPopup(auth, msProvider);
    })
    .then((result) => {
      localStorage.setItem("idUsuario", result.user.uid);

      router.push("/privado");
      console.log("Logueado con Microsoft");
    })
    .catch((error) => {
      console.error("Error Microsoft:", error.message);
      alert("Error al conectar con Microsoft");
    });
};

const iniciaSesionGoogle = () => {
  setPersistence(auth, browserSessionPersistence)
    .then(() => {
      return signInWithPopup(auth, provider);
    })
    .then((result) => {
      console.log("Logueado con Google");
      localStorage.setItem("idUsuario", result.user.uid);
      router.push("/privado");
    })
    .catch((error) => {
      console.error("Error Google:", error.message);
    });
};

function enviarCorrreoContraseña(email) {
  sendPasswordResetEmail(auth, email)
    .then(() => {
      alert("Correo enviado");
    })
    .catch((error) => {
      console.log(error.message);
    });
}

const registrar = () => {
  setPersistence(auth, browserSessionPersistence)
    .then(() => {
      return createUserWithEmailAndPassword(auth, email.value, contra.value);
    })
    .then((userCredential) => {
      localStorage.setItem("idUsuario", userCredential.user.uid);

      router.push("/privado");
      console.log("Registrado con persistencia de sesión");
      registrado.value = true;
    })
    .catch((error) => {
      console.error(error.message);
    });
};

function registro() {
  registrado.value = true;
}

function inicia() {
  iniciado.value = true;
}
</script>
<template>
  <div>
    <div class="login" v-if="!registrado && !iniciado && !olvidadoContraseña">
      <h3>Acceso</h3>
      <button @click="iniciaSesionGoogle">Inicia Sesión con Google</button>
      <button @click="iniciaSesionMicrosoft">Inicia Sesion Microsoft</button>
      <button @click="registro">Registrarse</button>
      <button @click="inicia">Tengo cuenta Email</button>
    </div>

    <div v-if="olvidadoContraseña">
      <input v-model="correoOlvidado" type="email" placeholder="Email" />
      <button @click="enviarCorrreoContraseña(correoOlvidado)">
        Enviar correo
      </button>
      <button @click="olvidadoContraseña = false">Volver</button>
    </div>

    <div v-if="iniciado && !olvidadoContraseña">
      <h3>Iniciar Sesión con Email</h3>
      <input v-model="email" type="email" placeholder="Email" />
      <input v-model="contra" type="password" placeholder="Contraseña" />
      <button @click="iniciarSesionEmail">Iniciar Sesión</button>
      <button @click="olvidadoContraseña = true">Olvidé mi contraseña</button>
      <button @click="iniciado = false">Volver</button>
    </div>

    <div v-if="registrado">
      <h3>Registrarse</h3>
      <form @submit.prevent="registrar">
        <label>Correo Electronico</label>
        <input v-model="email" type="email" name="email" />
        <label>Contraseña</label>
        <input v-model="contra" type="password" name="contra" />
        <button type="submit">Registrarse</button>
        <button @click="registrado = false">Volver</button>
      </form>
    </div>
  </div>
</template>

<style scoped>
/* Contenedor de la tarjeta de login/registro */
.auth-container {
  max-width: 400px;
  margin: 3rem auto;
  padding: 2.5rem;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.05);
  font-family: "Segoe UI", sans-serif;
  text-align: center;
}

h3 {
  color: #2c3e50;
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 2rem;
  letter-spacing: -0.5px;
}

/* Estructura de formularios y labels */
form {
  display: flex;
  flex-direction: column;
  text-align: left;
}

label {
  font-size: 0.85rem;
  color: #636e72;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

input {
  width: 100%;
  padding: 0.8rem 1rem;
  margin-bottom: 1.5rem;
  border: 1px solid #dfe6e9;
  border-radius: 6px;
  background-color: #f9f9f9;
  font-size: 0.95rem;
  transition: border-color 0.3s ease;
  box-sizing: border-box;
}

input:focus {
  outline: none;
  border-color: #2c3e50;
  background-color: #ffffff;
}

/* Botones Principales (Acción directa) */
button {
  width: 100%;
  padding: 0.9rem;
  margin-bottom: 0.8rem;
  border: none;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: block;
}

/* Botón destacado (Google, Iniciar, Registrar) */
button:not([click*="Volver"]):not([click*="olvidado"]) {
  background-color: #2c3e50;
  color: #ffffff;
}

button:not([click*="Volver"]):not([click*="olvidado"]):hover {
  background-color: #34495e;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Botones Secundarios (Volver, Olvidé contraseña) */
button[click*="Volver"],
button[click*="olvidado"],
button[click*="registro"],
button[click*="inicia"] {
  background-color: transparent;
  color: #636e72;
  border: 1px solid #dfe6e9;
  margin-top: 0.5rem;
}

button[click*="Volver"]:hover,
button[click*="olvidado"]:hover {
  background-color: #f8f9fa;
  color: #2c3e50;
  border-color: #b2bec3;
}

/* Estilo específico para separadores visuales si fuera necesario */
.login button:first-of-type {
  background-color: #ffffff;
  color: #444;
  border: 1px solid #dfe6e9;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.login button:first-of-type:hover {
  background-color: #f1f1f1;
}
</style>
